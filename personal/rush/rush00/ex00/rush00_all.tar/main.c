#include "rush00.c"
int main(){
	rush(-5,6);
//	int y=20;
//	int x=20;
//	for(int j=-10;j<x;j++) {
//		for(int i=-10;i<y;i++){
//			rush(i,j);
//		}
//	}
	return 0;
}
